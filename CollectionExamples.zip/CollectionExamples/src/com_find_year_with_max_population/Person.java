package com_find_year_with_max_population;

import java.util.Objects;

public class Person {
    String name;
    int yearOfBirth;
    int dateOfDeath;

    public Person(String name, int yearOfBirth,int yearOfDeath){
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.dateOfDeath = yearOfDeath;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return yearOfBirth == person.yearOfBirth &&
                dateOfDeath == person.dateOfDeath &&
                Objects.equals(name, person.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, yearOfBirth, dateOfDeath);
    }
}


