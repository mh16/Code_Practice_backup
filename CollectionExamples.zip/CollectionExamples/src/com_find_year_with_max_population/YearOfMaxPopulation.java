package com_find_year_with_max_population;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class YearOfMaxPopulation {

    public static void main(String args[]) {
        Set<Person> person = new HashSet<Person>();
        person.add(new Person("Hussain1", 2000, 2005));
        person.add(new Person("Hussain3", 2000, 2001));
        person.add(new Person("Hussain4", 2000, 2002));
        person.add(new Person("Hussain5", 2000, 2003));

        person.add(new Person("Hussain2", 2001, 2002));
        person.add(new Person("Hussain2", 2001, 2003));



        HashMap<Integer, Integer> birthMap = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> deathMap = new HashMap<Integer, Integer>();
        int birthCount;
        int deathCount;

        for (Person p : person) {

            if (birthMap.get(p.yearOfBirth) != null) {
                birthCount =birthMap.get(p.yearOfBirth);
                //just to avoid adding when year of birth and year of death are same
                if(p.yearOfBirth != p.dateOfDeath ){
                    birthMap.put(p.yearOfBirth,++birthCount);
                }

            } else {
                if(p.yearOfBirth != p.dateOfDeath){
                    birthMap.put(p.yearOfBirth, 1);
                }else {
                    birthMap.put(p.yearOfBirth, 0);
                }

            }

            // not required.we can do this with one Hashmap
//            if (deathMap.get(p.dateOfDeath) != null) {
//                deathCount =deathMap.get(p.dateOfDeath);
//                deathMap.put(p.dateOfDeath, ++deathCount);
//            } else {
//                deathMap.put(p.dateOfDeath, 1);
//            }


        }

        // get value of key 3
        int val = (int)birthMap.get(2001);
        // check the value
        System.out.println("Value for key 2000 is: " + val);



        for (Integer key : birthMap.keySet()) {
            Integer value = birthMap.get(key);
            System.out.println("Key = " + key + ", Value = " + value);
        }





    }

    static int fibo(int  n){
        switch (n){
            default:
                return fibo(n-1) + fibo(n-2);
            case 1:
            case 2:
        }
        return 1;

    }
}