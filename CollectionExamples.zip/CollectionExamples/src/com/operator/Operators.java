package com.operator;

public class Operators {
    public static void main(String[] args) {
       // int a=b=1; //case 1

//        if(1==1){
//            int b =0;
//            System.out.println("Hello " +b);
//        }

//        if(1==1)
//            int b;
//        System.out.println("Hello ");
    }
}
