package com.linklist.doubly_linked_list;


// Class for Doubly Linked List
public class DoubleLinkedList {
    Node head; // head of list

    /* Doubly Linked list DoubleLinkedList*/
    class Node {
        int data;
        Node prev;
        Node next;

        // Constructor to create a new node
        // next and prev is by default initialized as null
        Node(int d) {
            data = d;
        }
    }
}
