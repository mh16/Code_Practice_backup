package com.linklist;

public class A {
}
