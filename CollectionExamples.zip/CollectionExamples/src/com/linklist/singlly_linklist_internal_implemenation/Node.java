package com.linklist.singlly_linklist_internal_implemenation;

// Node class
public class Node {
    int data;
    Node next;

    // Constructor to create a new node
    Node(int data) {
        this.data = data;
    }

    Node(){

    }
}
