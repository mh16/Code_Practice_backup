package com.linklist.singlly_linklist_internal_implemenation;

public class LL1 {
    Node head;

    public boolean isEmpty() {
        return (head == null);

    }


    public void insert(int data) {
        // whatever will be inserted , it will be inserted after last item if any, else need to insert at first ans update head

        Node randomNode = new Node();
        randomNode.data = data;
        randomNode.next = null;//means, this is added at last

        if (head == null) {//for the first time.
            head = randomNode;
        } else {
            //if we aready have nodes inserted,then need to iterate
            Node node = head;
            while (node.next !=null) {
                node = node.next;
            }
            node.next = randomNode;
        }


    }

    public void insertFirst(int data) {
        //Simply means,newly added will node will be the first new , so need to assign head to newly insert head

        Node firstNode = new Node();
        firstNode.data = data;
        firstNode.next = head;
        head = firstNode;

    }

    public void show() {
        //need to traverse fro head to last element
        Node node = head;//traverse till node.next is null. here null means, last item
        while (node.next != null) {
            System.out.println(node);
            node = node.next;
        }
    }
}
