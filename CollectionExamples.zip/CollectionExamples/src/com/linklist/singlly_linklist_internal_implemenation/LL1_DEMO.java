package com.linklist.singlly_linklist_internal_implemenation;

public class LL1_DEMO {
    public static void main(String args[]) {

        LL1 ll1 = new LL1();
        ll1.insert(5);


        ///show
        ll1.show();

    }
}
