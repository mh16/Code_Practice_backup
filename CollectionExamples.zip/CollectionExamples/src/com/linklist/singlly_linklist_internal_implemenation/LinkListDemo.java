package com.linklist.singlly_linklist_internal_implemenation;



public class LinkListDemo {

    public static void  main(String args[]){
        LinkedList linkedList = new LinkedList();
        linkedList.insert(5);
        linkedList.insert(15);
        linkedList.insert(18);

        // insert at beginning
        //linkedList.insertAtStart(23);

       // linkedList.insertAt(0,65);

        //Deletion operation
        linkedList.deleteAt(0);

        //show method to print linkedlist values
        linkedList.show();



    }
}
