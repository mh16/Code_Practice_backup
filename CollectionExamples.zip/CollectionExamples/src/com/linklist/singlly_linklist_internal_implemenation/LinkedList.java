package com.linklist.singlly_linklist_internal_implemenation;


// Linked list example in Java
// Linked list class
class LinkedList {
    // head of list
    Node head;

    public void insert(int data) {
        Node node = new Node();
        node.data = data;
        node.next = null;

        //
        if (head == null) {
            head = node;
        } else {
            Node n = head;
            //traverse till next we reach to last element where n.next will be  null
            while (n.next != null) {
                n = n.next;
            }
            //when we reach new
            n.next = node;
        }
    }

    public void insertAtStart(int data) {
        Node node = new Node();
        node.data = data;
        node.next = null;
        node.next = head;// this simply means now head points to next node and inserted item will be new head.
        head = node;// now insrted node becomes head

    }


    public void insertAt(int index, int data) {
        Node node = new Node();
        node.data = data;
        node.next = null;

        // special case: if any item added at 0th Location
        if (index == 0) {
            insertAtStart(data);
            return;//this return is required,else element will be added twice

        }
        Node n = head;//traversal start from head,
        for (int i = 0; i < index - 1; i++) {
            n = n.next;
        }
        node.next = n.next;
        n.next = node;
    }


    public void deleteAt(int index) {
        // for delete at beginning
        if (index == 0) {
            head = head.next;//assigns next element as head
            return;
        }
        //
        Node n = head;//traversal of nodes start with head
        Node n1 = null;//temprary variable to hold value after deletion
        for (int i = 0; i < index - 1; i++) {
            //
            n = n.next;
        }
        n1 = n.next;
        n.next = n1.next;
        System.out.println("Deleted item n1  " + n1.data);
        //though n1 is deleted, but it is still in memory.so need to nullify to make it eligible for garbage collection
    }

    public void show() {
        Node node = head;
        while (node.next != null) {
            System.out.println(node.data);
            node = node.next;
        }//it will print n-1 item
        System.out.print(node.data);

    }

}


