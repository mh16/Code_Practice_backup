package com.overriding_overloading;

public class ParentClass {

//    public void show(){
//        System.out.println("show() method in parent class");
//    }

    public static void staticShow(){
        System.out.println("staticShow method in parent class");
    }


}
