package com.overriding_overloading;



/* Java program which demonstrate that we can not override static method in Java.
        * Had Static method can be overridden, with Super class type and sub class object
 * static method from sub class would be called in our example, which is not the case.
        * @author
 */


import java.awt.*;

public class CanWeOverrideStaticMethod {

    public static void main (String args []){

        ChildClass parentClass = new ChildClass();

        //parentClass.show();
        parentClass.staticShow();

        MyBook book = new MyBook();
        book.title = "Hi";
        System.out.println();


    }


    abstract static class Book{
        String title;
        abstract void setTitle(String s);
        String getTitle(){
            return title;
        }
    }

    static class MyBook extends Book{

        @Override
        void setTitle(String s) {
            this.setTitle(s);
        }
    }
}
