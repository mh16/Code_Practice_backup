package com.overriding_overloading;

 public class ChildClass extends ParentClass {

    /*
     * static method of same name and method signature as existed in super
     * class, this is not method overriding instead this is called
     * method hiding in Java
     */
    public static void staticShow(){
        System.err.println("staticShow method in Child Class in Java");
    }
}
