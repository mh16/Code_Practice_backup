package com.hashmap;


import java.util.HashMap;
import java.util.Map;

/**
 * How duplicate key is prevented in hashmap ?
 */
public class HashMapDemo {

    public static void main(String args[]) {
        //
        preventDuplicateKeyInHashMap();

    }
    /**
     * How duplicate key is prevented in hashmap ?
     */
    private static void preventDuplicateKeyInHashMap(){
        //HashMap map = new HashMap();
        //As we all know hashmap doesn’t allow duplicates in the key even though we insert the same key
        // with different values the latest value only is returned.
        Map map = new HashMap();
        map.put(1, "sam");
        map.put(1, "Ian");
        map.put(1, "Scott");
        map.put(null, "asdf");

        System.out.println(map);
        //Output: For the above code, you will get the output as {null=asdf, 1=Scott}  as the values sam,Ian will be
        // replaced by Scott , So how does this happen.

        //Reason: All the Entry Objects in the LinkedList will have the same hashcode but hashmap uses  equals () method
        // checks the equality if key.equals(k) is true then it will replace the value object inside the Entry class
        // and not the key. So this way it prevents the duplicate key being inserted.
    }

    /**
     * How put works in hashmap

    public V put(K key, V value) {
        if (key == null)
            return putForNullKey(value);
        int hash = hash(key.hashCode());
        int i = indexFor(hash, table.length);

        for (Entry<K, V> e = table[i]; e != null; e = e.next) {
            Object k;
            if (e.hash == hash && ((k = e.key) == key || key.equals(k))) {
                V oldValue = e.value;
                e.value = value;
                e.recordAccess(this);
                return oldValue;
            }
        }

        modCount++;
        addEntry(hash, key, value, i);
        return null;
    }*/

    /**
     * How get() works in HashMap
     */

    /**
     *
     First, it gets the hashcode of the key object which is passed and finds the bucket location.
     If the correct bucket is found it returns the value (e.value)
     If no match is found it returns null.

     public V get(Object key)
    {
        if (key == null)
            return getForNullKey();
        int hash = hash(key.hashCode());
        for (Entry<K,V> e = table[indexFor(hash, table.length)];e != null;e = e.next)
        {
            Object k;
            if (e.hash == hash && ((k = e.key) == key || key.equals(k)))
                return e.value;
        }
        return null;
    }*/

}
