package com.stack;

import java.util.Arrays;

/**
 * Stack implementation using array/
 * LIFO
 */
public class Stack {
    int stack[] = new int[5];
    int top;

    public void push(int data){
        stack[top] =data;
        top++;

    }

    public int pop(){
        top--;
        //getting data at top
        int data = stack[top];
        // after pop , need to make it 0 or -1
        stack[top] =0;//deleting element
        return data;
    }

    public int peek(){//peek is same as pop  but no deleting
        //getting data at top
        int data = stack[top-1];

        return data;
    }
    public int size(){
        return top;
    }
    public boolean isEmpty(){
        return top<=0;
    }

    public void show() {
        //System.out.println(Arrays.toString(stack));
        for(int n:stack){
            System.out.println(n +" ");

        }

    }

}


