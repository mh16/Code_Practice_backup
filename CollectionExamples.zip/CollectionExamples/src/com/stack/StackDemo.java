package com.stack;

public class StackDemo {
    public static void main(String args[]) {
        //LIFO

        Stack stack = new Stack();
        stack.push(20);
        stack.push(34);
        stack.push(45);
        stack.push(75);
        stack.push(28);


//        //pop operation: bottom to top
//        System.out.println("After Pop "+stack.pop());
//

        // Peek
        //System.out.println("After Peek  "+stack.peek());

        //Size


        //show
        stack.show();


    }
}

