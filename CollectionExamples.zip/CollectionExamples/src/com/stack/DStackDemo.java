package com.stack;

public class DStackDemo {
    public static void main(String args[]) {
        //LIFO

        DStack stack = new DStack();
        stack.push(20);
        stack.show();
        stack.push(34);
        stack.show();
        stack.push(45);
        stack.show();
        stack.push(75);
        stack.show();
        stack.push(28);
        stack.show();

        //pop
        System.out.println("Pop");
        stack.pop();
        stack.show();
        stack.pop();
        stack.show();
        stack.pop();
        stack.show();
        stack.pop();
        stack.show();
        stack.pop();
        stack.show();
        stack.pop();
        stack.show();




    }
}

