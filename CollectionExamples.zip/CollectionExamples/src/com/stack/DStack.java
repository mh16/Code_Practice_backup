package com.stack;

import java.util.Arrays;

/**
 * Stack implementation using array/
 * LIFO
 */
public class DStack {
    int capacity = 2;
    int stack[] = new int[capacity];
    int top;

    public void push(int data) {
        if (size() == capacity) {
            expand();
        }
        stack[top] = data;
        top++;

    }

    private void expand() {
        int lenght = size();
        //we can have different multiples as per our requirement. even initial capacity
        int newStack[] = new int[capacity * 2];
        System.arraycopy(stack,0,newStack,0,lenght);//we can have a loop
        stack =newStack;
        //capacity = capacity*2;
        capacity *=2;



    }

    public int pop() {
        int data =0;
        if(isEmpty()){
            System.out.println("Stack is empty");
        }else{
            top--;
            //getting data at top
             data = stack[top];
            // after pop , need to make it 0 or -1
            stack[top] = 0;//deleting element
            shrink();
        }

        return data;
    }

    private void shrink() {
        int lenght = size();
        if(lenght<=((capacity/2)/ 2)){
            capacity = capacity/2;
        }

        int newStack[] = new int[capacity];
        System.arraycopy(stack,0,newStack,0,lenght);//we can have a loop
        stack =newStack;
        //capacity = capacity*2;
        capacity *=2;
    }

    public int peek() {//peek is same as pop  but no deleting
        //getting data at top
        int data = stack[top - 1];

        return data;
    }

    public int size() {
        return top;
    }

    public boolean isEmpty() {
        return top <= 0;
    }

    public void show() {
        System.out.println(Arrays.toString(stack));
//        for (int n : stack) {
//            System.out.println(n + " ");
//
//        }

    }

}


