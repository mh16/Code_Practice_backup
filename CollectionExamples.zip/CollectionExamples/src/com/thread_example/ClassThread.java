package com.thread_example;

public class ClassThread extends Thread {



}
