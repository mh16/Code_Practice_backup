package com.abstact_interface;

public interface IEmpInfo {
    void getSalaryInfo();
    void getEmpInfo();
    //interfaces are abstract and public by default
}
