package com.abstact_interface;

public abstract class AbstractBaseClass {

    int  getSalaryInfo(int yearsOfExperience){
        //Concrete part
        //Implementation
        int baseFactor = 3;
        int industryNormalizationFactor = 200000;

        return ((baseFactor* ((yearsOfExperience*100000)) -industryNormalizationFactor));

    }

    public abstract void getEmpInfo();

    public static void toTodo(){
        //
    }
}
