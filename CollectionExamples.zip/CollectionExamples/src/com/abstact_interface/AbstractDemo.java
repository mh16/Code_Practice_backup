package com.abstact_interface;

public class AbstractDemo extends  AbstractBaseClass{
    public static void main(String ars[]){
        AbstractDemo abstractDemo = new AbstractDemo();
        abstractDemo.getEmpInfo();

    }

    @Override
    public void getEmpInfo() {
        //Need to provide own implementation

        Employee employee = new Employee();
        employee.setName("Mohammad Mumtaz Hussain");
        employee.setDesignation("Consultant");
        employee.setSalaryPerMonth(this.getSalaryInfo(8));// get sal info from base
        System.out.println("Emp Name:: "+employee.getName() +"\n"+"Salary per month:: "+ employee.getSalaryPerMonth());

    }
}
