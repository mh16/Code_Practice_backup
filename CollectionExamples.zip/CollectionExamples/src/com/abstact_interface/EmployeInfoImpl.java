package com.abstact_interface;

public class EmployeInfoImpl implements IEmpInfo {
    @Override
    public void getSalaryInfo() {

    }

    @Override
    public void getEmpInfo() {

    }
}
