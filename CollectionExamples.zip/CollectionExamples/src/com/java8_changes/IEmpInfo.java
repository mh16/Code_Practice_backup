package com.java8_changes;

public interface IEmpInfo {
    void getSalaryInfo();
    void getEmpInfo();

    default  void getEmpProjectInfo(){

    }
}
