package com.ngro.nth_prime;

public class StringRearrange {


    public static void main(String[] args) {
        String intial ="abcdeldhdd";
        String outPut= "bddeskdlsdk";
        System.out.println("Original string "+ intial);

        int index =3;
        char ch = outPut.charAt(3);
        System.out.println("character at index 3 of outPut "+ ch);

        StringBuilder stringBuilder = new StringBuilder(outPut);

        for(int i =0; i<=intial.length();i++){
            stringBuilder.setCharAt(i,ch);
            // Print the modified string
//            System.out.println("Modified String = "
//                    + stringBuilder);

        }
        System.out.println("Modified String = "
                + stringBuilder);
    }



    private static void  dummy(){
        String str = "Welcome to string handling tutorial";
        char ch1 = str.charAt(0);
        char ch2 = str.charAt(5);
        char ch3 = str.charAt(11);
        char ch4 = str.charAt(20);
        System.out.println("Character at 0 index is: "+ch1);
        System.out.println("Character at 5th index is: "+ch2);
        System.out.println("Character at 11th index is: "+ch3);
        System.out.println("Character at 20th index is: "+ch4);
    }

    private static void reArrangeString(String inputString){
        // replace the character with character at less than 3 index


//       for (int i =0; i <str.length();i++){
//           replace();
//       }
        System.out.println("replaced string  "+replace(inputString,3,inputString.charAt(3)));




    }

    public static String replace(String str, int index, char replace){
        if(str==null){
            return str;
        }else if(index<0 || index>=str.length()){
            return str;
        }
        char[] chars = str.toCharArray();
        chars[index] = replace;
        return String.valueOf(chars);
    }

    static String replace1(String str, String pattern, String replace) {
        int start = 0;
        int index = 0;
        StringBuffer result = new StringBuffer();

        while ((index = str.indexOf(pattern, start)) >= 0) {
            result.append(str.substring(start, index));
            result.append(replace);
            start = index + pattern.length();
        }
        result.append(str.substring(start));
        return result.toString();
    }



}
