//package com.ngro.nth_prime;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//
//public class NthPrimeDemo {
//    public static void main (String args []){
//        System.out.println(nth(11));
//    }
//
//    public static int nth(int x){
//        if(x<=0){throw new IllegalArgumentException();}
//        ArrayList<Integer> primes = new ArrayList<Integer>();
//        HashMap<Integer,String> numbers= new HashMap<Integer,String>();
//        primes = getPrimes(x*30);
//        return primes.get(x-1);
//
//    }
//
//
//    public static ArrayList<Integer> getPrimes(int limit){
//        ArrayList<Integer> primes = new ArrayList<Integer>();
//        if(limit==2){
//            primes.add(2);
//            return primes;
//        }
//        int nextNumber =2;
//        HashMap<Integer,String> numbers = new HashMap<Integer,String>();
//        while(nextNumber<=limit){
//            if(!numbers.containsKey(nextNumber)){
//                numbers.put(nextNumber, "Y");
//
//                for(int i=nextNumber*2;i<=limit;i+=nextNumber){
//                    numbers.put(i, "N");
//                }
//
//            }
//            nextNumber++;
//
//        }
//
//        for(int i=2;i<numbers.size();i++){
//            if(numbers.get(i).equals("Y")){
//                primes.add(i);
//            }
//        }
//
//        return primes;
//    }
//}
