package com.ngro.nth_prime;

public class NthPrime1 {
    public static void main(String[] args) {
        //prime numbers
        //2,3,5,7, 11,13,17,19,23,29, 31,37

        nthPrime1(10);

    }

    private static void nthPrime1(int nth) {
        int num, count, i;
        num = 1;
        count = 0;

        while (count < nth) {
            num = num + 1;
            for (i = 2; i <= num; i++) {
                if (num % i == 0) {
                    break;
                }
            }
            if (i == num) {
                count = count + 1;
            }
        }
        System.out.println("Value of nth prime: " + num);
    }


//    public static void getNthPrime1(int nthPrime) {
//        int num, count, i;
//
//        num = 1;
//        count = 0;
//
//        while (count < nthPrime) {
//            num = num + 1;
//
//            for (i = 2; i <= nthPrime; i++) {
//                if (num % i == 0) {
//                    break;
//                }
//            }
//            if (i==num) {
//                count = count +1;
//            }
//        }
//
//        System.out.println("Get nth prime  "+num);
//
//    }
}

