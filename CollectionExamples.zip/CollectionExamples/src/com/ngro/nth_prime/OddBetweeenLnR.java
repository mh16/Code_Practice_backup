package com.ngro.nth_prime;

public class OddBetweeenLnR {
    public static void main(String[] args) {

    }


}

