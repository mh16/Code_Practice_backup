//package com.ngro.nth_prime;
//
//public class nthPrimePractice {
//
//    public static void main(String[] args) {
//
//        getNthPrime1(10);
//
//    }
//
//    private static void getNthPrime1(int nthPrime) {
//        int num, count, i;
//
//        num = 1;
//        count = 0;
//
//        while (count < nthPrime) {
//            num = num + 1;
//
//            for (i = 2; i <= nthPrime; i++) {
//                if (num % i == 0) {
//                    break;
//                }
//            }
//            if (i==num) {
//                count = count +1;
//            }
//        }
//
//        System.out.println("Get nth prime  "+num);
//
//    }
//}
