package com.ngro;

import java.util.*;

public class CountFrequencyOfWord {
    public static void main(String[] args) {
        //List list = getList();

        getWordFrequencyUsingHashMap(getList());

        //Using HashSet
        getWordFrequencyUsingHashSet(getList());


    }

    private static void getWordFrequencyUsingHashMap(List<String> list) {
        System.out.println("getWordFrequencyUsingHashMap");
        HashMap<String, Integer> map = new HashMap<>();
        if (list == null || list.size() <= 0) {
            //we should throw two exceptions viz NullPointerException and IllegalArgumentException
            throw new NullPointerException("List should not be empty");
        }
        //Iterate through list and store list item as key and increment if
        for (String strKey : list) {
            //Need to add a check fro
            if (map.get(strKey) != null) {
                int count = map.get(strKey);
                map.put(strKey, ++count);

            } else {
                map.put(strKey, 1);//for very first time, as this time key will be null. TODO.update inline comment
            }

        }
        for (String stringKey : map.keySet()) {
            System.out.println("Element " + stringKey + " occurs " + map.get(stringKey));

        }

        //Time complexity looks like O(n^2)
    }

    private static void elementOccurrencesUsingHashMap1(ArrayList<String> list){

        //Hashmap to store frequency of element
        HashMap<String, Integer> map = new HashMap<>();

        for(String str : list){
            Integer key = map.get(str);
            map.put(str,(key ==null)?1:key+1);
        }
        // Check occurrences
        for (Map.Entry<String, Integer> entry : map.entrySet()){
            System.out.println("Occurrences for Key "+ entry.getKey() + "times" + entry.getValue());
        }

    }


    private static void getWordFrequencyUsingHashSet(List<String> list) {
        System.out.println("getWordFrequencyUsingHashSet");
        if (list == null || list.size() <= 0) {
            //we should throw two exceptions viz NullPointerException and IllegalArgumentException
            throw new NullPointerException("List should not be empty");
        }

        Set<String> hashSet = new HashSet<>(list);

        //iterate
        for(String stringKey: list){
            System.out.println("Element "+ stringKey +" occurs "+ Collections.frequency(list,stringKey));

        }




    }

    private static List<String> getList() {
        List<String> list = new ArrayList<>();
        list.add("IPHONE");
        list.add("Android");
        list.add("Blackberry");
        list.add("IPHONE");
        list.add("Android");
        list.add("BADA");
        list.add("BREW");
        list.add("Android");
        return list;
    }
}
