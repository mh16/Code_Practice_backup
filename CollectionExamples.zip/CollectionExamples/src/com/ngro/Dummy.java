package com.ngro;

public class Dummy {

    public static void main(String[] args) {
        System.out.println();


    }

}
