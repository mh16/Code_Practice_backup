package com.ngro;


import java.util.*;
import java.util.stream.Collectors;

/**
 * Situation - You have millions of records(Strings) and user is typing "abc" in search box .
 * Your task is to display strings from records in the sequence.
 * <p>
 * e.g String in the record contain "abc" starting should appear first, then string which has "abc" in the second,
 * should apprear later as below.
 * <p>
 * String - fabcsdf,asdfabc,dfadsfsdfabc,abckdf,ddfabc...
 * <p>
 * Displays suggestion like....
 * abckdf
 * fabcsdf
 * ddfabc
 * asdfabc
 * dfadsfsdfabc
 * <p>
 * Question - Which data structure you would use to store this ?
 * And how will you implement to get this(shorted) result
 */
public class StringSearch {
    public static void main(String[] args) {
        //stringSearchUsinfArrayList();//arraylist

        //stringSearchUsingHashMap1();//hashmap with java 8 stream support

        //
        stringSearchUsingHashMapIdeal();
        //stringSearchUsingTreeMap();

    }





    private static void stringSearchUsingTreeMap(){
        List<String> lisStr = new ArrayList<String>();
        List<String> lisStrModify = new ArrayList<String>();
        Map<Integer,String> treemap = new TreeMap<Integer,String>();
        lisStr.add("1234abcdef");
        lisStr.add("abcdef");
        lisStr.add("12abcdef");
        lisStr.add("1abcdef");
        lisStr.add("123abcdef");
        lisStr.add("12334afabcdef");
        lisStr.add("123sweede1abcdef");

        //
        for(int i = 0 ; i < lisStr.size(); i++){
            int loc = lisStr.get(i).indexOf("abc");
            if(loc != -1){
                treemap.put(loc,lisStr.get(i));

            }
        }
        System.out.println(treemap.toString());//seems like O(n),just a single loop


    }
    private static void stringSearchUsingHashMapIdeal(){
        List<String> lisStr = new ArrayList<String>();
        List<String> lisStrModify = new ArrayList<String>();
        Map<Integer,String> hashMap = new HashMap<>();
        lisStr.add("1234abcdef");
        lisStr.add("abcdef");
        lisStr.add("12abcdef");
        lisStr.add("1abcdef");
        lisStr.add("123abcdef");
        lisStr.add("12334afabcdef");
        lisStr.add("123sweede1abcdef");

        //
        for(int i = 0 ; i < lisStr.size(); i++){
            int loc = lisStr.get(i).indexOf("abc");
            System.out.println("loc indexOf  "+loc);

            if(loc != -1){
                hashMap.put(loc,lisStr.get(i));

            }
        }
        System.out.println(hashMap.toString());//seems like O(n),just a single loop


    }




    private static void stringSearchUsinfArrayList() {
        List<String> lisStr = new ArrayList<String>();
        List<String> lisStrModify = new ArrayList<String>();
        lisStr.add("1234abcdef");
        lisStr.add("abcdef");
        lisStr.add("12abcdef");
        lisStr.add("1abcdef");
        lisStr.add("123abcdef");

        for (int i = 0; i < lisStr.size(); i++) {
            for (int j = 0; j < lisStr.size(); j++) {
                if (lisStr.get(j).startsWith("abc", i)) {
                    lisStrModify.add(lisStr.get(j));
                }
            }
        }
        System.out.println(lisStrModify);// O(n^2)

    }

    private static void stringSearchUsingHashMap1() {
        String test = "avscfaabc";
        String test1 = "abcdrst";
        String test2 = "aasabcdfs";
        String test3 = "vbabcsdr";
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put(test, test.indexOf("abc"));
        map.put(test1, test1.indexOf("abc"));
        map.put(test2, test2.indexOf("abc"));
        map.put(test3, test3.indexOf("abc"));
        Map<String, Integer> sortedNewMap = map.entrySet().stream().sorted((e1, e2) -> e1.getValue().compareTo(e2.getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
        sortedNewMap.forEach((key, val) -> {
            System.out.println(key + " = " + val.toString());
        });

    }

}
