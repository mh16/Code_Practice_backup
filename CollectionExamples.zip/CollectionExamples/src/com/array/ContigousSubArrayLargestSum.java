package com.array;

import java.util.ArrayList;
import java.util.List;

public class ContigousSubArrayLargestSum {
    public static void main(String args[]) {
        int a[] = {-2, -3, 4, -1, -2, 1, 5, -3};
        System.out.println(" 1:Maximum contiguous sum is " +
                maxSubArraySum1(a));

        System.out.println("2:Maximum contiguous sum is " +
                maxSubArraySum2(a));

        // returning worg result
        System.out.println("3:Maximum contiguous sum is " +
                maxSubArraySum3(a));

        List<Integer> A = new ArrayList<>();


    }

    //This seems to be best answer
    static int maxSubArraySum1(int a[]) {
        int size = a.length;
        int max = Integer.MIN_VALUE, currentSum = 0;

        for (int i = 0; i < size; i++) {
            currentSum = currentSum + a[i];
            if (max < currentSum)
                max = currentSum;
            if (currentSum < 0)
                currentSum = 0;
        }
        return max;
    }


    //best
    static int maxSubArraySum2(int a[]) {
        if (a == null || a.length == 0) {
            throw new IllegalArgumentException("array must be non-empty non-null");
        }
        int max_so_far = a[0];
        int curr_max = a[0];

        for (int i = 1; i < a.length; i++) {
            curr_max = Math.max(a[i], curr_max + a[i]);
            max_so_far = Math.max(max_so_far, curr_max);
        }
        return max_so_far;
    }


    /**
     * Contiguous Sequence: Given an array of integers (positive and negative) find the
     * contiguous sequence with the highest sum and return the sum.
     * <p>
     * Assumptions:
     * <p>
     * Time complexity: O(n) where n is the size of the array
     * Space complexity: O(1)
     * <p>
     * Difference with book: I didn't like their choice of all negative arrays returning
     * 0, it should be as the question states IMO.
     */
    //Hussain
    public static int maxSubArraySum3(final int[] array) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException("array must be non-empty non-null");
        }
        int max = array[0];
        int currentSum = array[0];
        for (int i = 0; i < array.length; i++) {
//            if (currentSum + array[i] > 0) {
//                currentSum =currentSum +array[i];
//            } else {
//                currentSum = array[i];
//            }
            currentSum =Math.max(array[i],currentSum +array[i]);

            max = Math.max(max, currentSum);
        }
        return max;
    }


}
