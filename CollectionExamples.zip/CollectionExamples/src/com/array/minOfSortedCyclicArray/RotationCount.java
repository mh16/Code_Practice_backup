package com.array.minOfSortedCyclicArray;

class RotationCount {
    public static void main(String[] args) {
        int[] A = {8, 9, 10,11, 1, 2, 3, 4, 5, 6, 7};
        //int[] A =  {7,8,9,10,6};
        System.out.println("Element  " + A[rotation(A)] + " " + "is rotated  " + rotation(A) + " times");
    }


    static int rotation(int array[]) {
        int low = 0;
        int high = array.length - 1;
        int middle = (low + high) / 2;
        while (middle > low) {
            if (array[middle] < array[high])
                high = middle;
            else
                low = middle;
            middle = (high + low) / 2;
        }
        return middle + 1;
    }

    // Function to find the number of times the array is rotated
    public static int findRotationCount(int[] A) {
        // search space is A[left..right]
        int low = 0;
        int high = A.length - 1;

        // iterate till search space contains at-least one element
        while (low <= high) {
            // if the search space is already sorted, we have
            // found the minimum element (at index left)
            if (A[low] <= A[high]) {
                return low;
            }

            int mid = (low + high) / 2;

            // find next and previous element of the mid element
            // (in circular manner)
            int next = (mid + 1) % A.length;
            int prev = (mid - 1 + A.length) % A.length;

            // if mid element is less than both its next and previous
            // neighbor, then it is the minimum element of the array

            if (A[mid] <= A[next] && A[mid] <= A[prev]) {
                return mid;
            }

            // if A[mid..right] is sorted and mid is not the min element,
            // then pivot element cannot be present in A[mid..right] and
            // we can discard A[mid..right] and search in the left half

            else if (A[mid] <= A[high]) {
                high = mid - 1;
            }

            // if A[left..mid] is sorted then pivot element cannot be
            // present in it and we can discard A[left..mid] and search
            // in the right half

            else if (A[mid] >= A[low]) {
                low = mid + 1;
            }
        }

        // invalid input
        return -1;
    }


}
