package com.collections;

import java.util.*;

public class ElementOccurance {
    public static void main(String args []){
        //System.out.println("Hello World!");

        //elementOccurrencesUsingHashMap(getList());
        elementOcurrencessUsingHashSet(getList());

    }


    private static ArrayList getList() {
        ArrayList list = new ArrayList();
        list.add("Java");
        list.add("Android");
        list.add("iOS");
        list.add("Android");
        list.add("iOS");
        return list;
    }


    private static void elementOccurrencesUsingHashMap(ArrayList<String> list){

        //Hashmap to store frequency of element
        HashMap<String, Integer> map = new HashMap<>();

        for(String str : list){
            Integer key = map.get(str);
            map.put(str,(key ==null)?1:key+1);
        }
        // Check occurrences
        for (Map.Entry<String, Integer> entry : map.entrySet()){
            System.out.println("Occurrences for Key "+ entry.getKey() + "times" + entry.getValue());
        }

    }


    private static void elementOcurrencessUsingHashSet(ArrayList<String> list){

        // Passed list to hashset
        Set<String> hashSet = new HashSet<String>(list);

        for(String str : list){
            System.out.println("Element "+str +" occurs "+ Collections.frequency(list,str) );
        }

    }

    private static void elementOcurrencessUsingTreeSet(){

    }
}
