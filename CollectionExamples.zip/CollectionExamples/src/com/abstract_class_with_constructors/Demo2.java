package com.abstract_class_with_constructors;

public class Demo2 extends ClassAbstract {

    int a,b;
//    //Wrong approach
//    public Demo2(int i, int j,int a,int b){
//        this.i = i;
//        this.j = j;//super class variables
//        this.a =a;
//        this.b= b;
//    }

    public Demo2(int i, int j,int a,int b){
//        this.i = i;
//        this.j = j;//super class variables
        super(i,j);
        this.a =a;
        this.b= b;
    }

    //Suppose we have 100 of subsclasses, then we need to write super class boilerplate code which is not good.
}
