package com.abstract_class_with_constructors;


public class Demo1 extends ClassAbstract{

    int x,y;

//    //Wrong approach
//    public Demo1(int i, int j,int x,int y){
//        this.i = i;
//        this.j = j;//super class variables
//        this.x =x;
//        this.y= y;
//    }

    //right approach
    public Demo1(int i, int j,int x,int y){

//        this.i = i;
//        this.j = j;//super class variables
        super(i,j);
        this.x =x;
        this.y= y;
    }
}
