package com.abstract_class_with_constructors;

/**
 * Why we need constructor inside an abstract class
 * Answer: When any class extends an abstract classs, the constructor of sub class will invoke the constructors of super class
 * either implicitly or excplicitly. This "Chaining of Constructors" is one of the reason abstract class have constructors in java.
 */
public class AbstactDemoMain {
    public static void main(String args []){
        Demo1 demo1 = new Demo1(10,20,1,7);
        System.out.println("Demo1 class:: \n" + demo1.i +"\n"+demo1.j +"\n"+ demo1.x + "\n"+demo1.y );

        Demo2 demo2 = new Demo2(5,23,11,17);
        System.out.println("Demo2 class:: "+ demo2.i +"\n"+demo2.j +"\n"+ demo2.a + "\n"+demo2.b );

    }
}
