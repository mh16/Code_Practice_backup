package com.abstract_class_with_constructors;

abstract public class ClassAbstract {
    int i, j;
     //Lets have constructor inside abstract class
    public ClassAbstract(int i,int j){
        this.i =i;
        this.j=j;

    }
}

